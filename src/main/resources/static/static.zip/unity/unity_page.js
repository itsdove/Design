function TestSend(str) {
    window.parent.setId(str)
}